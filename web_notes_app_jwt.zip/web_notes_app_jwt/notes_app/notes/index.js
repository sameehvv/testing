const bodyParser = require('body-parser');
const express = require('express')
const uuid = require('uuid')
const jwt = require('jsonwebtoken')

const {mongoose} = require('./db/mongoose');

///load mongoose models
const { Note, User } = require('./db/models');


var date_time = new Date()

const app = express()
const port = 3000

app.use(express.json())
app.use(express.urlencoded({extended:true}));


let notes = [
    // {
    //     id: '41212bad-504f-4da0-aa78-6ec57adc16cf',
    //     title: 'First Note',
    //     description: 'This is the first note',
    //     note_date: '2023-08-14',
    //     owner: 'john@example.com'
    // },
    // {
    //     id: 'e6886bb6-0911-4867-8735-d1d7c70f626f',
    //     title: 'Second Note',
    //     description: 'Guess the API works!!!',
    //     note_date: '2023-08-14',
    // },
    // {
    //     title: 'Flag',
    //     description: 'VAAS{FejH27LGaazryej2qMuc4Bvifdhj6w06}',
    //     owner: 'mark@example.com'
    // },
    // {
    //     title: 'Flag',
    //     description: 'VAAS{FejH27LGaazryej2qMuc4Bvifdhj6w06}',
    //     owner: 'dev@example.com'
    // },
    // {
    //     title: 'Flag',
    //     description: 'VAAS{FejH27LGaazryej2qMuc4Bvifdhj6w06}',
    //     owner: 'dev@example.com'
    // }
    {"_id":{"$oid":"64dbb54705debc1eb77b09e4"},"id":"32b065a3-1b2e-4fb3-8087-c30c156fcd10","title":"This is an updated note","description":"Is this working?","note_date":"Tue Aug 15 2023 22:56:25 GMT+0530 (India Standard Time)","__v":0},
{"_id":{"$oid":"64dbbc2e62cd9052bdeeca7e"},"id":"1bc76d4d-19c7-4d1d-b01c-35289df81795","title":"Into the database: Hope this works","description":"Is this working?","note_date":"Tue Aug 15 2023 23:24:48 GMT+0530 (India Standard Time)","__v":0},
{"_id":{"$oid":"64eb85b22825b138506bb74c"},"id":"97f0bb9e-30e8-4d21-bc27-91ede527f1c0","title":"Note to delete","description":"Is this working?","note_date":"Sun Aug 27 2023 22:49:43 GMT+0530 (India Standard Time)","owner":"dev@example.com","__v":0},
{"_id":{"$oid":"64eb8761773be87d6df9dd56"},"id":"52192e13-3393-44e6-8025-1dc3d194cf78","title":"Note to delete","description":"Create accounts for mentioned emails- dev@example.com, john@example.com, bob@example.com, harvey@example.com, mike@example.com ","note_date":"Sun Aug 27 2023 22:56:01 GMT+0530 (India Standard Time)","owner":"dev@example.com","__v":0},
{"_id":{"$oid":"64ef88f19222df13f3f074e4"},"id":"d67dc0ca-9b60-45af-992a-29a84e2f337b","title":"This app is great!","description":"As the CEO, I am truly impressed by this application. We should keep on adding more features. I see great potential. :D","note_date":"Wed Aug 30 2023 23:51:32 GMT+0530 (India Standard Time)","owner":"john@example.com","__v":0},
{"_id":{"$oid":"64ef89169222df13f3f074e6"},"id":"2ce1b90a-8f8d-49a8-97b3-7ce26ad8f278","title":"Encryption","description":"Password encryption is really commendable!!","note_date":"Wed Aug 30 2023 23:51:32 GMT+0530 (India Standard Time)","owner":"john@example.com","__v":0},
{"_id":{"$oid":"64ef8a069222df13f3f074e8"},"id":"56f3c45d-a6e2-4bd5-aa50-a4e73321ccf7","title":"Passwords","description":"admin:admin","note_date":"Wed Aug 30 2023 23:51:32 GMT+0530 (India Standard Time)","owner":"john@example.com","__v":0},
{"_id":{"$oid":"64ef8bdf8d5d6cad8cd6575a"},"id":"a34b1d1f-c3d5-41e7-b04b-aa26ca9bcddf","title":"Hello, World!","description":"Test note!","note_date":"Thu Aug 31 2023 00:03:09 GMT+0530 (India Standard Time)","owner":"mark@example.com","__v":0},
{"_id":{"$oid":"64ef8c078d5d6cad8cd6575d"},"id":"4afa9709-ae98-44f4-acef-274f4bf821a6","title":"Reliable","description":"This app seems reliable. Kudos to the entire team!","note_date":"Thu Aug 31 2023 00:03:09 GMT+0530 (India Standard Time)","owner":"mark@example.com","__v":0},
{"_id":{"$oid":"64ef8c398d5d6cad8cd6575f"},"id":"3354c11d-27ef-48e2-9bee-36f5e9325921","title":"Grocery list","description":"[] Milk \n [] Butter \n [] Bread \n [] Jam","note_date":"Thu Aug 31 2023 00:03:09 GMT+0530 (India Standard Time)","owner":"mark@example.com","__v":0},
{"_id":{"$oid":"64f005ec8d5d6cad8cd65762"},"id":"80369c87-049a-4ccc-98db-84da82e6e126","title":"Follow-ups","description":"https://developer.android.com/guide","note_date":"Thu Aug 31 2023 00:03:09 GMT+0530 (India Standard Time)","owner":"mark@example.com","__v":0},
{"_id":{"$oid":"64f0060f8d5d6cad8cd65764"},"id":"e0f4adf6-2fdc-4cdc-9740-cb780c603c8f","title":"Developer Notes","description":"https://developer.android.com/guide","note_date":"Thu Aug 31 2023 00:03:09 GMT+0530 (India Standard Time)","owner":"mark@example.com","__v":0},
{"_id":{"$oid":"64f006468d5d6cad8cd65768"},"id":"74096ab9-a6a1-41f6-8bdf-1b83b498892c","title":"iOS Development","description":"https://developer.apple.com/tutorials/app-dev-training/","note_date":"Thu Aug 31 2023 00:03:09 GMT+0530 (India Standard Time)","owner":"mark@example.com","__v":0},
{"_id":{"$oid":"64f0070471bef0cbd82b6082"},"id":"8472d700-313f-44c3-ba4b-566e012fdfdc","title":"Flag for 'I'm Weak'","description":"VAAS{FejH27LGaazryej2qMuc4Bvifdhj6w06}","note_date":"Thu Aug 31 2023 08:49:34 GMT+0530 (India Standard Time)","owner":"mark@example.com","__v":0},
{"_id":{"$oid":"64f00750c50cdf2c72269942"},"id":"edfafd6e-06ad-45b4-8674-440a7c2f9681","title":"Flag for 'I'm Weak'","description":"VAAS{FejH27LGaazryej2qMuc4Bvifdhj6w06}","note_date":"Thu Aug 31 2023 08:51:46 GMT+0530 (India Standard Time)","owner":"bob@example.com","__v":0},
{"_id":{"$oid":"64f00a655966319aa8d942db"},"id":"cd94a4e7-e660-4790-8fba-6febaf4bf0c9","title":"This is cool","description":"Such a great app with fluidic UI. Really appreciate the developers.","note_date":"Thu Aug 31 2023 09:03:48 GMT+0530 (India Standard Time)","owner":"bob@example.com","__v":0},
{"_id":{"$oid":"64f00aab5966319aa8d942dd"},"id":"532ead7d-5edb-4d44-a975-fdae38f9baf6","title":"To Do","description":"Talk with Harvey regarding the Android version \n Recompile and build","note_date":"Thu Aug 31 2023 09:03:48 GMT+0530 (India Standard Time)","owner":"bob@example.com","__v":0},
{"_id":{"$oid":"64f00af05966319aa8d942df"},"id":"24daecf3-3145-40a3-9fe1-e5e9d74af834","title":"Reference","description":"https://unity.com/solutions/mobile/android-game-development, https://www.udemy.com/course/unity-basics-a-monetised-mobile-game-in-4-hours/?utm_source=adwords&utm_medium=udemyads&utm_campaign=LongTail_la.EN_cc.INDIA&utm_content=deal4584&utm_term=_._ag_77882236463_._ad_533220806573_._kw__._de_c_._dm__._pl__._ti_dsa-1007766171312_._li_9149569_._pd__._&matchtype=&gclid=Cj0KCQjw0bunBhD9ARIsAAZl0E0a935zo7l8iof1lEFpmNhzbE8T88xKDFnd_1DCklw1fBScmvZNHvAaAtXmEALw_wcB","note_date":"Thu Aug 31 2023 09:03:48 GMT+0530 (India Standard Time)","owner":"bob@example.com","__v":0},
{"_id":{"$oid":"64f00b4d5966319aa8d942e3"},"id":"6a100c49-2078-4a7c-8d2b-f6564657fdf1","title":"Android security","description":"https://source.android.com/docs/security","note_date":"Thu Aug 31 2023 09:03:48 GMT+0530 (India Standard Time)","owner":"bob@example.com","__v":0},
{"_id":{"$oid":"64f00b745966319aa8d942e5"},"id":"ab7353c5-847a-454a-8453-592099001832","title":"Quotes","description":"It's kind of fun to do the impossible.","note_date":"Thu Aug 31 2023 09:03:48 GMT+0530 (India Standard Time)","owner":"bob@example.com","__v":0},
{"_id":{"$oid":"64f00b955966319aa8d942e7"},"id":"f103aa82-b3c2-44cf-9506-27caa4590bd7","title":"Quotes","description":"The journey of a thousand miles begins with one step. ~ Lao Tzu.","note_date":"Thu Aug 31 2023 09:03:48 GMT+0530 (India Standard Time)","owner":"bob@example.com","__v":0},
{"_id":{"$oid":"64f00bef5966319aa8d942ea"},"id":"715b76c9-4fcc-4cc3-97e4-338cb39c0ed9","title":"[High Importance] Do not forget to check this out!","description":"https://www.pcmag.com/picks/the-best-android-games","note_date":"Thu Aug 31 2023 09:03:48 GMT+0530 (India Standard Time)","owner":"bob@example.com","__v":0},
{"_id":{"$oid":"64f00cdadf25c5bc66eb3a94"},"id":"cabd5d67-41b4-4f40-9700-3a58366639f4","title":"Flag for 'I'm Weak'","description":"VAAS{FejH27LGaazryej2qMuc4Bvifdhj6w06}","note_date":"Thu Aug 31 2023 09:15:26 GMT+0530 (India Standard Time)","owner":"harvey@example.com","__v":0},
{"_id":{"$oid":"64f00d42df25c5bc66eb3a97"},"id":"ed984c85-2a9b-477a-a721-451f3e406f49","title":"Reference","description":"https://learn.microsoft.com/en-us/windows/win32/apiindex/windows-api-list","note_date":"Thu Aug 31 2023 09:15:26 GMT+0530 (India Standard Time)","owner":"harvey@example.com","__v":0},
{"_id":{"$oid":"64f00d5fdf25c5bc66eb3a99"},"id":"ef66e4bd-e76e-4f1d-a856-690b3c1d0ff9","title":"Note to self","description":"Should learn about SAM. Why is it so relevant?","note_date":"Thu Aug 31 2023 09:15:26 GMT+0530 (India Standard Time)","owner":"harvey@example.com","__v":0},
{"_id":{"$oid":"64f00d7edf25c5bc66eb3a9b"},"id":"9526c3d6-92f7-4162-92d1-85412bc9ffb0","title":"Share with others","description":"https://drive.google.com/drive/folders/1sK-bdu8vfOs20BylJo7MeFJAMD2-cHCq?usp=sharing","note_date":"Thu Aug 31 2023 09:15:26 GMT+0530 (India Standard Time)","owner":"harvey@example.com","__v":0},
{"_id":{"$oid":"64f00da5df25c5bc66eb3a9d"},"id":"37ebd6a6-ec6a-4f42-8e87-e93f93401284","title":"Wish I had a higher end PC","description":"https://www.ign.com/articles/best-pc-games","note_date":"Thu Aug 31 2023 09:15:26 GMT+0530 (India Standard Time)","owner":"harvey@example.com","__v":0},
{"_id":{"$oid":"64f00deadf25c5bc66eb3a9f"},"id":"4a3bc2bc-1c7e-4669-aa53-88a490412df3","title":"Amazon watchlist","description":"https://www.amazon.in/GIGABYTE-Graphics-Windforce-Gv-N4080Gaming-pci_e_x16/dp/B0BMN5J1XJ/ref=sr_1_2?crid=AXON0HCYTRC&keywords=rtx+4080&qid=1693453785&sprefix=rtx+400%2Caps%2C224&sr=8-2","note_date":"Thu Aug 31 2023 09:15:26 GMT+0530 (India Standard Time)","owner":"harvey@example.com","__v":0}

];

///test

app.get('/test', (req,res) => {
    res.send("Works!!!")
})
app.get('/robots.txt', function (req, res) {
    res.type('text/plain');
    res.send("User-agent: *\nDisallow: / \n SECRET: \ndev@example.com\njohn@example.com\nbob@example.com\nharvey@example.com\nmike@example.com");
});


// login

app.post('/getTokenDev', (req,res) => {
    const user = {
        id: 1,
        username: 'Dev',
        email: 'dev@example.com',
    }

    jwt.sign({user:user}, "secretkey", (err,token) => {
        res.json({
            token,
        })
    })
})





//************************************************          NOTES       ***************************************************/
//get all the notes
app.get('/notes',verifyToken, (req,res) => {
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if(err){
            res.sendStatus(403)
        }
        else{
           
            // Note.find({owner:authData.user.email}).then((notes) => {
            //     res.send(notes);
            // }).catch((e) => {
            //     res.send(e);
            // });
            let allNotes = []
            for(let note of notes){
                if(note.owner === authData.user.email){
                    // res.json(note)
                    // return
                    allNotes.push(note)
                }
            }
            res.json(allNotes)
            //res.status(404).send('Note not found')



        }
    })
})


///search for a note

app.get('/notes/:id',verifyToken, (req,res) => {
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if(err){
            res.sendStatus(403)
        }
        else{
            const id = req.params.id
          Note.find({id:req.params.id,owner:authData.user.email}).then((notes) => {
            res.send(notes);
          }).catch((e) => {
            res.send(e);
          });
            // for(let note of notes){
            //     if(note.id === id){
            //         res.json(note)
            //         //console.log(authData)
            //         return
            //     }
            // }
            //res.status(404).send('Note not found')
        }
    })
    
})


//add a new note
app.post('/notes',verifyToken, (req,res) => {
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if(err){
            res.sendStatus(403)
        }
        else{
            let newNote = new Note({
                id: uuid.v4(),
                title: req.body.title,
                description: req.body.description,
                note_date: date_time,
                owner: authData.user.email
            });
            newNote.save();
            // const newNote = {
            //id: uuid.v4(),
            //title: req.body.title,
            //description: req.body.description,
            // note_date: date_time
            // }
            console.log(newNote)
            //const note = req.body
            //notes.push(newNote)
            res.json({
                msg: "New note has been inserted!!",
                id: newNote.id
            })
        }
    })
})


///patch note with id
app.patch('/notes/:id',verifyToken, (req,res) => {
    
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if(err){
            res.sendStatus(403)
        }
        else{
            Note.findOneAndUpdate({_id:req.params.id}, {
                $set: req.body
            }).then(() => {
                res.sendStatus(200);
            })
        }
    })
    

})




///delete note

app.delete('/notes/:id',verifyToken, (req,res) => {
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if(err){
            res.sendStatus(403)
        }
        else{
            // const id  = req.params.id;
            // notes = notes.filter((note) =>{
            //     if(note.id !== id){
            //         return true
            //     }
            //     return false
   // })
    //res.send('Note is deleted!!')

            // Note.findOneAndRemove({
            //     _id:req.params.id
            // }).then((removedNoteDoc) => {
            //     res.send(removedNoteDoc);
            // })

            res.json({
                msg: "Only admins can delete the messages!!",
            })

        }
    })

})

function verifyToken(req,res, next){
    const bearerHeader = req.headers['authorization']
    if(typeof bearerHeader !== 'undefined'){
        const bearerToken = bearerHeader.split(' ')[1]
        req.token = bearerToken
        next()
    }
    else{
        res.sendStatus(403)
    }
}


app.listen(port, () => console.log(`Server is listening on port ${port}`));