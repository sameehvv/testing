#! /bin/bash

mongoimport --host mongodb --db NotesManager --collection notes --type json --file /data/notes --jsonArray