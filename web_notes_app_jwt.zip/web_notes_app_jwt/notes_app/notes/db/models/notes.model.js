const mongoose = require('mongoose');

const NotesSchema = new mongoose.Schema({
    id: {
        type: String,
        required: true,
        minlength: 1,
        trim: true
    },
    title:{
        type: String,
        required: true,
        minlength:1,
        trim:true
    },
    description:{
        type: String,
        required: true,
        minlength:1,
        trim:true
    },
    note_date:{
        type:String,
        required: true,
        minlength:1,
        trim:true
    },
    owner:{
        type:String,
        required: true,
        minlength:1,
        trim:true
    }
})

const Note = mongoose.model('Note',NotesSchema);

module.exports = {Note}