const mongoose = require('mongoose');

const UsersSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        minlength: 1,
        trim: true
    },
    name:{
        type: String,
        required: true,
        minlength:1,
        trim:true
    },
    email:{
        type: String,
        required: true,
        minlength:1,
        trim:true
    },
    passwordd:{
        type:String,
        required: true,
        minlength:1,
        trim:true
    }
})

const User = mongoose.model('User',UsersSchema);

module.exports = {User}