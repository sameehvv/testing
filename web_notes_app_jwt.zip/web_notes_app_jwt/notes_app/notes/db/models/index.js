const { Note } = require('./notes.model');
const { Users } = require('./users.model')

module.exports = {
    Note
}